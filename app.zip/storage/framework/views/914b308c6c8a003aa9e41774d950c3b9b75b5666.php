<div class="column-left">
                    <div class="sidebox">
                        
                        <!-- ************** Start LEFT Menu **************************************** -->
                                                <!-- ************** End LEFT Menu ****************************************** -->
                    </div>
                </div><?php /**PATH /home/i40yc9b8pvxq/public_html/resources/views/template/includes/sidebar.blade.php ENDPATH**/ ?>