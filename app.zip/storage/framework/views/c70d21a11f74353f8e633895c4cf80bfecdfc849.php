
<?php $__env->startSection('title', 'Customers'); ?>
<?php $__env->startSection('content'); ?>    
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">  
<link href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css" rel="stylesheet" />
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script> 
<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Customers</h4>
                  
                  <div class="table-responsive pt-3">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>
                            #
                          </th>
                          <th>
                          Name
                          </th>
                          <th>
                            Email
                          </th>
                          <th>
                            Phone
                          </th>
                          <th>
                            Registerd On
                          </th>
                          <th>
                            Plan
                          </th>
                          <th>
                            Amount
                          </th>
                          
                          <th>
                           Status
                          </th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                           <?php echo e($customer->id); ?>

                          </td>
                          <td><?php echo e($customer->name); ?></td>
                          <td>
                           <?php echo e($customer->email); ?>

                          </td>
                          <td>
                          <?php echo e($customer->phone); ?>

                          </td>
                          <td>
                          <?php echo e($customer->created_at); ?> 
                          </td>
                          <td>
                          <?php echo e(ucwords($customer->plan)); ?> 
                          </td>
                          <td>
                          <?php echo e($customer->amount); ?> BTC 
                          </td>
                          <td>
                          <select name="account_status" class="account_status" rel="<?php echo e($customer->id); ?>">
                            <option value="1" <?php if($customer->active_status == 1): ?> selected <?php endif; ?>>Active</option>
                            <option value="0" <?php if($customer->active_status == 0): ?> selected <?php endif; ?>>Inactive</option>
                          </select>                          
                          </td>
                          
                        </tr> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                        
                      </tbody>
                      
                    </table>
                    <div class="d-flex">
    <?php echo $customers->links(); ?>

</div>                 
                  </div>
                </div>
              </div>
            </div>
            <script>
                $(document).ready(function(){
                  $(".account_status").on('change', function(){
                    if(confirm("Do you want to change the status")){
                    var userID = $(this).attr('rel');
                    var account_status = $(this).val();
                  
                    $.ajaxSetup({
                      headers: {
                          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                      }
                    });
                    $.ajax({
                        url: '<?php echo e(Route('change.account.status')); ?>',
                        data: {
                          'userID': userID, 'account_status':account_status
                        },
                        type: 'POST',
                        dataType: 'json',
                        success: function(data) {
                          if(data.success = 1)
                          {
                            alert(data.message);
                          }
                        }
                        
                    });
                  
                    }
                  
                    
                  })
                  
                })
              </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/i40yc9b8pvxq/public_html/resources/views/admin/customers.blade.php ENDPATH**/ ?>