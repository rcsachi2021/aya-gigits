
<?php $__env->startSection('title', 'Transactions'); ?>
<?php $__env->startSection('content'); ?>       
<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Your Transactions</h4>
                  
                  <div class="table-responsive pt-3">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>
                            #
                          </th>
                          <th>
                            Transaction ID
                          </th>
                          <th>
                            Plan
                          </th>
                          <th>
                            Amount
                          </th>
                          <th>
                            Type
                          </th>
                          <th>
                            Payment date
                          </th>
                          <th>
                            Status
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                           <?php echo e($transaction->id); ?>

                          </td>
                          <td>
                           <?php echo e($transaction->transaction_id); ?>

                          </td>
                          <td>
                          <?php echo e($transaction->plan); ?>

                          </td>
                          <td>
                          <?php echo e($transaction->amount); ?> BTC
                          </td>
                          <td>
                          <span class="<?php if($transaction->type == 'debit'): ?> text-danger <?php else: ?> text-success <?php endif; ?>"> <?php echo e(ucfirst($transaction->type)); ?></span>
                          </td>
                          <td>
                          <?php echo e($transaction->created_at); ?>

                          </td>
                          <td>
                          <span class="<?php if($transaction->payment_status == 'pending'): ?> text-danger <?php else: ?> text-success <?php endif; ?>"><?php echo e(ucfirst($transaction->payment_status)); ?></span>
                          </td>
                        </tr> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                      
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pec1\aya\resources\views/dashboard/transactions.blade.php ENDPATH**/ ?>