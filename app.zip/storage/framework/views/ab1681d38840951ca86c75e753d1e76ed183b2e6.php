
<?php $__env->startSection('title', 'Transactions'); ?>
<?php $__env->startSection('content'); ?>    
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">  
<link href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css" rel="stylesheet" />
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script> 
<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Your Transactions</h4>
                  
                  <div class="table-responsive pt-3">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>
                            #
                          </th>
                          <th>
                            Customer
                          </th>
                          <th>
                            Transaction ID
                          </th>
                          <th>
                            Plan
                          </th>
                          <th>
                            Amount
                          </th>
                          <th>
                            Type
                          </th>
                          <th>
                            Payment date
                          </th>
                          <th>
                            Payment Status
                          </th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                           <?php echo e($transaction->id); ?>

                          </td>
                          <td><?php echo e($transaction->userdetails->name); ?></td>
                          <td>
                           <?php echo e($transaction->transaction_id); ?>

                          </td>
                          <td>
                          <?php echo e(ucwords($transaction->plan)); ?>

                          </td>
                          <td>
                          <?php echo e($transaction->amount); ?> BTC
                          </td>
                          <td>
                          <span class="<?php if($transaction->type == 'credit'): ?> text-success <?php else: ?> text-danger <?php endif; ?>"><?php echo e(ucwords($transaction->type)); ?></span>
                          </td>
                          <td>
                          <?php echo e($transaction->created_at); ?>

                          </td>
                          <td>
                          <select name="payment_status" class="payment_status" rel="<?php echo e($transaction->id); ?>" id="account_status-<?php echo e($transaction->userdetails->id); ?>">
                            <option value="pending" <?php if($transaction->payment_status == 'pending'): ?> selected <?php endif; ?>>Pending</option>
                            <option value="completed" <?php if($transaction->payment_status == 'completed'): ?> selected <?php endif; ?>>Completed</option>
                          </select>                          
                          </td>
                          
                        </tr> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                        
                      </tbody>
                      
                    </table>
                    <div class="d-flex">
    <?php echo $transactions->links(); ?>

</div>                 
                  </div>
                </div>
              </div>
            </div>
            <script>
                $(document).ready(function(){
                  $(".payment_status").on('change', function(){
                    if(confirm("Do you want to change the status")){
                    var transactionID = $(this).attr('rel');
                    var payment_status = $(this).val();
                    var ids = $(this).attr('id');
                    id = ids.split('-');
                    userID = id[1];
                    $.ajaxSetup({
                      headers: {
                          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                      }
                    });
                    $.ajax({
                        url: '<?php echo e(Route('change.payment.status')); ?>',
                        data: {
                          'transactionID': transactionID, 'payment_status':payment_status, 'userID':userID
                        },
                        type: 'POST',
                        dataType: 'json',
                        success: function(data) {
                          if(data.success = 1)
                          {
                            alert(data.message);
                          }
                        }
                        
                    });
                  
                    }
                  
                    
                  })
                  
                })
              </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/i40yc9b8pvxq/public_html/resources/views/admin/transactions.blade.php ENDPATH**/ ?>