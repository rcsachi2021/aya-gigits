<footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <a href="#" target="_blank">Aya Capital </a>2023</span>
            
          </div>
        </footer><?php /**PATH D:\xampp\htdocs\pec1\aya\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>