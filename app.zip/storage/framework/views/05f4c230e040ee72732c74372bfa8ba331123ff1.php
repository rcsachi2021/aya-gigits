
<?php $__env->startSection('title', 'Reset Password'); ?>
<?php $__env->startSection('content'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo asset('assets/dashboard/vendors/ti-icons/css/themify-icons.css'); ?>">
  <link rel="stylesheet" href="<?php echo asset('assets/dashboard/vendors/base/vendor.bundle.base.css'); ?>">
<link rel="stylesheet" href="<?php echo asset('assets/dashboard/css/style.css'); ?>">
<form action="<?php echo e(Route('processlogin')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-center auth px-0">
        <div class="row w-100 mx-0">
          <div class="col-lg-4 mx-auto">
            <?php if(session()->has('message')): ?>
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
          <?php echo e(session()->get('message')); ?>

          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php endif; ?>
            <div class="auth-form-light text-left py-5 px-4 px-sm-5">
              
              
              <h6 class="font-weight-light">Enter Your Email</h6>
              <form class="pt-3" action="<?php echo e(Route('processlogin')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input type="email" class="form-control form-control-lg" id="email" name="email" placeholder="Email ID">
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="mt-3">
                  <button type="submit" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn">Submit</button>
                  
                </div>
               
                <div class="text-center mt-4 font-weight-light">
    
    <span class="psw"><a href="<?php echo e(Route('login')); ?>">Sign in?</a></span>
  </div>
                <!-- <div class="text-center mt-4 font-weight-light">
                  Don't have an account? <a href="register.html" class="text-primary">Create</a>
                </div> -->
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
</form>
<script src="<?php echo asset('assets/dashboard/vendors/base/vendor.bundle.base.js'); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/i40yc9b8pvxq/public_html/resources/views/forgetpassword.blade.php ENDPATH**/ ?>