<nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(Route('dashboard')); ?>">
              <i class="ti-shield menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(Route('admin.customers')); ?>">
              <i class="ti-layout-list-post menu-icon"></i>
              <span class="menu-title">Customers</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(Route('admin.sendmessage')); ?>">
              <i class="ti-layout-list-post menu-icon"></i>
              <span class="menu-title">Send Message</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(Route('admin.transactions')); ?>">
              <i class="ti-layout-list-post menu-icon"></i>
              <span class="menu-title">Transactions</span>
            </a>
          </li>
                    
          
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(Route('profile')); ?>">
              <i class="ti-user menu-icon"></i>
              <span class="menu-title">Profile</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="chatify">
              <i class="ti-comment-alt menu-icon"></i>
              <span class="menu-title">Chat</span>
            </a>
          </li>
        </ul>
      </nav><?php /**PATH D:\xampp\htdocs\pec1\aya\resources\views/admin/includes/sidenavbar.blade.php ENDPATH**/ ?>