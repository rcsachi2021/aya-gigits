
<?php $__env->startSection('banner'); ?>
<header>
<img src="assets/images/banner1.jpg">
</header>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'Vera+'); ?>
<?php $__env->startSection('class','demo100'); ?>
<?php $__env->startSection('content'); ?>
<p>Our seamless application enables users to access interest-earning across multiple asset classes in one single place. Built to facilitate the alignment of decentralized lending markets that interoperate with real-world financial data. Our vision is to an open, global financial system that is easily accessible to everyone.</p>
<p><img src="assets/images/star.png" width="18">		Buy Crypto With Every Portfolio Purchase Vera+ l rounds up your everyday purchases to the next dollar and invests that spare change into crypto. Want to grow your investments even faster? Boost each round-up with a 2x, 3x, or 4x multiplier. Build wealth on the blockchain with each roundup. </p>
<p>
    <img src="assets/images/star.png" width="18"> 		Recurring Dollar Cost Average To Beat Market Volatility Set up automatic investments at regular intervals within the Vera+ bot to strengthen the value of your micro-investments. These can occur on a monthly, weekly, or even daily basis. Whatever your sweet, HODLing heart desires.
</p>
<p>
   <img src="assets/images/star.png" width="18"> 		One-Time Feeling Lucky? Make a One-Off Purchas Make a one-time investment into any of the 150+ cryptos listed on Vera+ to build your digital asset wealth. This single purchase can reflect whatever amount you choose. Good luck.
</p>
<p>
    <img src="assets/images/star.png" width="18"> 		TriggeredVera+ social or environmental news that may affect crypto prices. Say a random famous person (like Elon Musk) decides to tweet about Dogecoin. The Vera+ algorithm will leverage its smart portfolio management tool to reallocate your basket and hold more Dogecoin. Through these triggered price alerts, Vera+ aims at turning hot gossip into high returns.
</p>
<p>
    <img src="assets/images/star.png" width="18"> FOREX
VERA+ Forex Algorithm: The international currency market Forex is one of the most dynamic and volatile. National currencies of different countries are bought and sold here. A good Forex robot is the key to profitable trading in this market even without your participation. Below are 5 reasons why you should activate your VERA+ Forex Robot
</p>
<p>
   <h3 style="color:#0062b0; font-size: 1.3rem;">Stability</h3> 
The Vera+ forex robot is a trader's years of experience written into software code. She performs dozens of trade transactions daily with high precision, without emotion, breaks, and days off.
</p>
<p>
    <h3 style="color:#0062b0; font-size: 1.3rem;">Automation</h3>
The robot does not require manual intervention, it includes 3 order execution types, 9 trading timers, 2 built-in indicators for technical analysis, and the simultaneous use of currency pairs.
</p>
<p>
   <h3 style="color:#0062b0; font-size: 1.3rem;">Profitability</h3> 
The average profit is between 5 and 25% per month. Without the participation of third parties.
All investments are in your exclusively controlled portfolio and do not transfer to trusted management to third parties. The speed of withdrawal. Money can be withdrawn from the stock exchange in less than 1 minute. Do you want to earn profits and spend time doing what you love while the robot works for you? Then Time To Activate the VERA+ Forex Robot and be sure of tomorrow!
By implementing years of experience in asset management amongst other areas of our digitalization ecosystem, the AYA group secures robust connections to key smart contracts and public data sources to provide guilds on its platform with a full suite of operational tooling to cover everything from analytics to payouts.
</p>
<p>
    For more inquiries or guidance
Contact us out via
Website <a href="<?php echo e(route('contact')); ?>"><img src="assets/images/website.png" width="34"></a> &nbsp; <a href="mailto:Info.ayauk@ayacapitaluk.com"><img src="assets/images/email.jpg" width="38"></a> &nbsp; <a href="https://www.linkedin.com/company/aya-capital-uk/" target="_blank"><img src="assets/images/linkedin.png" width="36"></a>
</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/i40yc9b8pvxq/public_html/resources/views/vera.blade.php ENDPATH**/ ?>