<div class="column-left">
                    <div class="sidebox">
                        
                        <!-- ************** Start LEFT Menu **************************************** -->
                                                <!-- ************** End LEFT Menu ****************************************** -->
                    </div>
                </div><?php /**PATH D:\xampp\htdocs\pec1\aya\resources\views/template/includes/sidebar.blade.php ENDPATH**/ ?>