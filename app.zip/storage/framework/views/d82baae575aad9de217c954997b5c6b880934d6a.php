
<?php $__env->startSection('title', 'Portfolio'); ?>
<?php $__env->startSection('class','demo10'); ?>
<?php $__env->startSection('content'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
<div class="row">
                        <div class="col-md-3 col-sm-6">
                            <div class="pricingTable10">
                                <div class="pricingTable-header">
                                    <h3 class="heading">Pollux</h3>                                   
                                </div>
                                <div class="pricing-content">
                                    <ul>
                                        <li>Profit range: 12-50%</li>
                                        <li>Trading period: 30-60 days</li>
                                        <li>Capital: 1 BTC</li>
                                    </ul>

                                    <a href="<?php echo e(Route('signup',encrypt('pollux'))); ?>" class="read">Activate Portfolio</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="pricingTable10">
                                <div class="pricingTable-header">
                                    <h3 class="heading">Antares</h3>                         
                                </div>
                                <div class="pricing-content">
                                    <ul>
                                        <li>Profit range: 20-80%</li>
                                        <li>Trading period: 30-60 days</li>
                                        <li>Capital: 5 BTC</li>                                        
                                    </ul>                                    
                                    <a href="<?php echo e(Route('signup',encrypt('antares'))); ?>" class="read">Activate Portfolio</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="pricingTable10">
                                <div class="pricingTable-header">
                                    <h3 class="heading">Tauri</h3>                              
                                </div>
                                <div class="pricing-content">
                                    <ul>
                                        <li>Profit range: 80-120%</li>
                                        <li>Trading period: 30-60 days</li>
                                        <li>Capital: 10 BTC</li>                                       
                                    </ul>
                                    <a href="<?php echo e(Route('signup',encrypt('tauri'))); ?>" class="read">Activate Portfolio</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="pricingTable10">
                                <div class="pricingTable-header">
                                    <h3 class="heading">Exclusive </h3>                            
                                </div>
                                <div class="pricing-content">
                                    <ul>
                                        <li>Profit range: 120-250%</li>
                                        <li>Trading period: six months </li>
                                        <li>Capital: 50 BTC</li>                                       
                                    </ul>
                                    <a href="<?php echo e(Route('signup',encrypt('exclusive'))); ?>" class="read">Activate Portfolio</a>
                                </div>
                            </div>
                        </div>
                    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pec1\aya\resources\views/portfolio.blade.php ENDPATH**/ ?>