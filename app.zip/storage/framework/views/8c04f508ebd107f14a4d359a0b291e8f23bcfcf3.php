<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="" class="">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
        
        <meta name="viewport" content="width=990, target-densityDpi=device-dpi">
        <meta name="MobileOptimized" content="990">
        <meta name="HandheldFriendly" content="true">
        <meta name="format-detection" content="telephone=no">
        <meta http-equiv="x-rim-auto-match" content="none">
        <title>Feedback - AYA Securities</title>
        <meta name="description" content="Feedback">
        <meta name="keywords" content="Feedback">
        <link href="<?php echo asset('assets/css/common.css'); ?>" rel="stylesheet"> 
        <link href="<?php echo asset('assets/css/feedback.css'); ?>" rel="stylesheet">               
        <link href="<?php echo asset('assets/css/highslide.css'); ?>" rel="stylesheet">        
           
        <style>
           
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
h1.page-title {
    font-size: 28px !important;
    font-weight: bold !important;
    color: #00447c;
    margin-top: 4px;
    margin-bottom: 12px;
}
        </style>
        <!-- Latest compiled and minified CSS -->
<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"> -->
<!--[if lt IE 9]>
        <link rel="stylesheet" type="text/css" href="/css/smart/ie.css" />
<![endif]-->        
<script src="<?php echo asset('assets/js/jquery.min.js'); ?>"></script>
        <script src="<?php echo asset('assets/js/modernizr.js'); ?>"></script> 
<!--[if lt IE 9]>
        <script type="text/javascript" src="/jscripts/libs/html5shiv/html5.js"></script>
<![endif]-->        
    <body>
        <div class="body-overlay"></div>
        <div class="body-container">
            <?php echo $__env->make('template.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="page-container clearfix col-md-12 col-sm-12" style="min-height: 504px;">
                <?php echo $__env->make('template.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="column-center">
                    <h1 class="page-title"><?php echo $__env->yieldContent('title'); ?></h1>

                </div>
              <div class="<?php echo $__env->yieldContent('class'); ?>">
                <div class="container">
                    <?php echo $__env->yieldContent('content'); ?>                    
                </div>
            </div>
            </div>
<?php echo $__env->make('template.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH D:\xampp\htdocs\pec1\aya\resources\views/template/master.blade.php ENDPATH**/ ?>