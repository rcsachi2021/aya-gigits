<div class="header-container">
                <div class="line"></div>
                
               
                <!-- ************** Start MAIN Menu **************************************** -->
                <ul class="nav">
                    <li><a href="<?php echo e(Route('home')); ?>"><span>Home</span></a></li>
                    <li><a href="<?php echo e(Route('portfolio')); ?>"><span>Portfolios</span></a></li>
                    <li><a href="<?php echo e(Route('affiliate')); ?>"><span>Affiliate</span></a></li>
                    <li class="last"><a href="<?php echo e(Route('contact')); ?>"><span>Contact</span></a></li>
                </ul>
                <!-- ************** End MAIN Menu ****************************************** -->
                <a class="logo" href="/">
                    <img src="assets/images/logo.jpg" alt="">
                </a>
                <div class="toolbar">
                   <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(Route('logout')); ?>" title="Login">
                        <img alt="Login" src="<?php echo asset('assets/images/f68d19a192a0e18d39c06d.png'); ?>">Logout
                    </a>  
                    <?php endif; ?>                           
                    <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(Route('login')); ?>" title="Login">
                        <img alt="Login" src="<?php echo asset('assets/images/f68d19a192a0e18d39c06d.png'); ?>">Login
                    </a>
                    <?php endif; ?>
                    
                    
                </div>
                
            </div>
            <div id="google_translate_element"></div><?php /**PATH D:\xampp\htdocs\pec1\aya\resources\views/template/includes/header.blade.php ENDPATH**/ ?>