<div class="footer-container clearfix">
                <div class="left">
                    AYA Capital Ltd<br>
                    57 Princes Gate Exhibition Road,<br>
                    United Kingdom, SW72PG
                </div>
                <div class="center">
                    Info.ayauk@ayacapitaluk.com<br>
                    Ayacapital.uk@gmail.com
                </div>
                <div class="right">
                    Copyright 2010-2015 <br>
AYA Capital. All Rights Reserved.<br>

                </div>
            </div>
        </div>
    
<script type="text/javascript">
function googleTranslateElementInit() {
    new google.translate.TranslateElement({pageLanguage: 'en' , includedLanguages : 'en,fr'}, 'google_translate_element');
  }
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script><?php /**PATH /home/i40yc9b8pvxq/public_html/resources/views/template/includes/footer.blade.php ENDPATH**/ ?>