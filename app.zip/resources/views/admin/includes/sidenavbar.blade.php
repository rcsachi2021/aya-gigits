<nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="{{Route('admin.dashboard')}}">
              <i class="ti-shield menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="{{Route('admin.customers')}}">
              <i class="ti-layout-list-post menu-icon"></i>
              <span class="menu-title">Customers</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="{{Route('admin.sendmessage')}}">
              <i class="ti-layout-list-post menu-icon"></i>
              <span class="menu-title">Send Message</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="{{Route('admin.transactions')}}">
              <i class="ti-layout-list-post menu-icon"></i>
              <span class="menu-title">Transactions</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="{{Route('admin.renewals')}}">
              <i class="ti-layout-list-post menu-icon"></i>
              <span class="menu-title">Renewals</span>
            </a>
          </li>
                    
          
          
        </ul>
      </nav>